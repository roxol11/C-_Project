var searchData=
[
  ['form1',['Form1',['../class_quiz_1_1_form1.html',1,'Quiz.Form1'],['../class_quiz_1_1_form1.html#ac1fb4002b8f982250c5e3f164e805dd0',1,'Quiz.Form1.Form1()'],['../class_quiz_1_1_form1.html#ac1fb4002b8f982250c5e3f164e805dd0',1,'Quiz.Form1.Form1()']]],
  ['form1_2ecs',['Form1.cs',['../_form1_8cs.html',1,'(Global Namespace)'],['../_quiz_2_form1_8cs.html',1,'(Global Namespace)']]],
  ['form1_2edesigner_2ecs',['Form1.Designer.cs',['../_form1_8_designer_8cs.html',1,'(Global Namespace)'],['../_quiz_2_form1_8_designer_8cs.html',1,'(Global Namespace)']]],
  ['funkcja_5fprzyciskow',['funkcja_przyciskow',['../class_quiz_1_1_q_u_i_z.html#a4b80197f1cab998cab42862c40f92730',1,'Quiz::QUIZ']]],
  ['funkcje_2ecs',['Funkcje.cs',['../_funkcje_8cs.html',1,'']]]
];
