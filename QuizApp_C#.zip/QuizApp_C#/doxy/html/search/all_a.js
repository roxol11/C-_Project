var searchData=
[
  ['scalarreturn',['scalarReturn',['../class_quiz_1_1klasa__zwrotna.html#aa34ec0bca25616370c77ca0dc5bdb86d',1,'Quiz::klasa_zwrotna']]],
  ['settings',['Settings',['../class_quiz_1_1_properties_1_1_settings.html',1,'Quiz::Properties']]],
  ['settings_2edesigner_2ecs',['Settings.Designer.cs',['../_properties_2_settings_8_designer_8cs.html',1,'(Global Namespace)'],['../_quiz_2_properties_2_settings_8_designer_8cs.html',1,'(Global Namespace)']]],
  ['startgame',['startgame',['../class_quiz_1_1startgame.html',1,'Quiz.startgame'],['../class_quiz_1_1startgame.html#a7f36964a70cd0cf7dfb60c83af3873a8',1,'Quiz.startgame.startgame()'],['../class_quiz_1_1startgame.html#a7f36964a70cd0cf7dfb60c83af3873a8',1,'Quiz.startgame.startgame()']]],
  ['startgame_2ecs',['startgame.cs',['../_quiz_2startgame_8cs.html',1,'(Global Namespace)'],['../startgame_8cs.html',1,'(Global Namespace)']]],
  ['startgame_2edesigner_2ecs',['startgame.Designer.cs',['../_quiz_2startgame_8_designer_8cs.html',1,'(Global Namespace)'],['../startgame_8_designer_8cs.html',1,'(Global Namespace)']]]
];
