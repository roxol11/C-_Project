var searchData=
[
  ['klasa_5fzwrotna',['klasa_zwrotna',['../class_quiz_1_1klasa__zwrotna.html',1,'Quiz']]],
  ['koniec_5fgry',['koniec_gry',['../class_quiz_1_1koniec__gry.html',1,'Quiz']]]
];
