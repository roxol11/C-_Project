var searchData=
[
  ['scalarreturn',['scalarReturn',['../class_quiz_1_1klasa__zwrotna.html#aa34ec0bca25616370c77ca0dc5bdb86d',1,'Quiz::klasa_zwrotna']]],
  ['startgame',['startgame',['../class_quiz_1_1startgame.html#a7f36964a70cd0cf7dfb60c83af3873a8',1,'Quiz.startgame.startgame()'],['../class_quiz_1_1startgame.html#a7f36964a70cd0cf7dfb60c83af3873a8',1,'Quiz.startgame.startgame()']]]
];
