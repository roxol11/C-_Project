var searchData=
[
  ['form1_2ecs',['Form1.cs',['../_form1_8cs.html',1,'(Global Namespace)'],['../_quiz_2_form1_8cs.html',1,'(Global Namespace)']]],
  ['form1_2edesigner_2ecs',['Form1.Designer.cs',['../_form1_8_designer_8cs.html',1,'(Global Namespace)'],['../_quiz_2_form1_8_designer_8cs.html',1,'(Global Namespace)']]],
  ['funkcje_2ecs',['Funkcje.cs',['../_funkcje_8cs.html',1,'']]]
];
