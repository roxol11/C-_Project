var searchData=
[
  ['settings',['Settings',['../class_quiz_1_1_properties_1_1_settings.html',1,'Quiz::Properties']]],
  ['startgame',['startgame',['../class_quiz_1_1startgame.html',1,'Quiz']]]
];
