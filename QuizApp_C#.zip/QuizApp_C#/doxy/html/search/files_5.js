var searchData=
[
  ['quiz_2ecs',['QUIZ.cs',['../_quiz_2_q_u_i_z_8cs.html',1,'(Global Namespace)'],['../_q_u_i_z_8cs.html',1,'(Global Namespace)']]],
  ['quiz_2edesigner_2ecs',['QUIZ.Designer.cs',['../_quiz_2_q_u_i_z_8_designer_8cs.html',1,'(Global Namespace)'],['../_q_u_i_z_8_designer_8cs.html',1,'(Global Namespace)']]]
];
