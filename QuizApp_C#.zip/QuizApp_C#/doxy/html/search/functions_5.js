var searchData=
[
  ['quiz',['QUIZ',['../class_quiz_1_1_q_u_i_z.html#a8f3343028dddeab999b08c808f58fa42',1,'Quiz.QUIZ.QUIZ()'],['../class_quiz_1_1_q_u_i_z.html#a8f3343028dddeab999b08c808f58fa42',1,'Quiz.QUIZ.QUIZ()']]]
];
