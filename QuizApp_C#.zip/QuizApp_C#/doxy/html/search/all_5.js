var searchData=
[
  ['name',['name',['../class_quiz_1_1startgame.html#a6c9156b0570418b99ab2ecd4d37bc5be',1,'Quiz::startgame']]],
  ['newprogressbar',['NewProgressBar',['../class_quiz_1_1_new_progress_bar.html',1,'Quiz.NewProgressBar'],['../class_quiz_1_1_new_progress_bar.html#ae206126e21080f0f57bbef13d87ca0d7',1,'Quiz.NewProgressBar.NewProgressBar()'],['../class_quiz_1_1_new_progress_bar.html#ae206126e21080f0f57bbef13d87ca0d7',1,'Quiz.NewProgressBar.NewProgressBar()']]],
  ['newprogressbar_2ecs',['NewProgressBar.cs',['../_new_progress_bar_8cs.html',1,'(Global Namespace)'],['../_quiz_2_new_progress_bar_8cs.html',1,'(Global Namespace)']]]
];
