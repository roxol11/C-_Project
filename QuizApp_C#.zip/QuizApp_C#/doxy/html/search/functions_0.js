var searchData=
[
  ['dispose',['Dispose',['../class_quiz_1_1_form1.html#a8305ce58c3acefe7cf42d3b3abe3efe0',1,'Quiz.Form1.Dispose()'],['../class_quiz_1_1koniec__gry.html#aca06a7d8f0015cab755b58531bc109b9',1,'Quiz.koniec_gry.Dispose()'],['../class_quiz_1_1_form1.html#a8305ce58c3acefe7cf42d3b3abe3efe0',1,'Quiz.Form1.Dispose()'],['../class_quiz_1_1_q_u_i_z.html#a177713a7ee491deea6d78dfafc9d0caa',1,'Quiz.QUIZ.Dispose()'],['../class_quiz_1_1startgame.html#a5886a87473f637307636ddf88e63d132',1,'Quiz.startgame.Dispose()'],['../class_quiz_1_1_q_u_i_z.html#a177713a7ee491deea6d78dfafc9d0caa',1,'Quiz.QUIZ.Dispose()'],['../class_quiz_1_1startgame.html#a5886a87473f637307636ddf88e63d132',1,'Quiz.startgame.Dispose()']]]
];
