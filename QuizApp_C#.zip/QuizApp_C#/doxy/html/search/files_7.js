var searchData=
[
  ['settings_2edesigner_2ecs',['Settings.Designer.cs',['../_properties_2_settings_8_designer_8cs.html',1,'(Global Namespace)'],['../_quiz_2_properties_2_settings_8_designer_8cs.html',1,'(Global Namespace)']]],
  ['startgame_2ecs',['startgame.cs',['../_quiz_2startgame_8cs.html',1,'(Global Namespace)'],['../startgame_8cs.html',1,'(Global Namespace)']]],
  ['startgame_2edesigner_2ecs',['startgame.Designer.cs',['../_quiz_2startgame_8_designer_8cs.html',1,'(Global Namespace)'],['../startgame_8_designer_8cs.html',1,'(Global Namespace)']]]
];
