var searchData=
[
  ['klasa_5fzwrotna',['klasa_zwrotna',['../class_quiz_1_1klasa__zwrotna.html',1,'Quiz']]],
  ['klasa_5fzwrotna_2ecs',['klasa_zwrotna.cs',['../klasa__zwrotna_8cs.html',1,'']]],
  ['koniec_20gry_2ecs',['koniec gry.cs',['../koniec_01gry_8cs.html',1,'']]],
  ['koniec_20gry_2edesigner_2ecs',['koniec gry.Designer.cs',['../koniec_01gry_8_designer_8cs.html',1,'']]],
  ['koniec_5fgry',['koniec_gry',['../class_quiz_1_1koniec__gry.html',1,'Quiz.koniec_gry'],['../class_quiz_1_1koniec__gry.html#a89d24b1b80804a9c27b1bb5f8fbe5274',1,'Quiz.koniec_gry.koniec_gry()']]]
];
