var searchData=
[
  ['klasa_5fzwrotna_2ecs',['klasa_zwrotna.cs',['../klasa__zwrotna_8cs.html',1,'']]],
  ['koniec_20gry_2ecs',['koniec gry.cs',['../koniec_01gry_8cs.html',1,'']]],
  ['koniec_20gry_2edesigner_2ecs',['koniec gry.Designer.cs',['../koniec_01gry_8_designer_8cs.html',1,'']]]
];
