var searchData=
[
  ['tab_5fzmian',['tab_zmian',['../class_quiz_1_1_q_u_i_z.html#a9bec15251c06c87f1aeb17cdaa828b2a',1,'Quiz::QUIZ']]]
];
