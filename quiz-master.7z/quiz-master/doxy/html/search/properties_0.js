var searchData=
[
  ['default',['Default',['../class_quiz_1_1_properties_1_1_settings.html#a8b72c94eb0fe2c18ce3cd1e002111c51',1,'Quiz::Properties::Settings']]]
];
