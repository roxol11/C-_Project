var searchData=
[
  ['properties',['Properties',['../namespace_quiz_1_1_properties.html',1,'Quiz']]],
  ['quiz',['Quiz',['../namespace_quiz.html',1,'']]]
];
