var searchData=
[
  ['wynik',['wynik',['../class_quiz_1_1_q_u_i_z.html#a3e189cfc9fe9e644e65c8e0b386b65fa',1,'Quiz::QUIZ']]]
];
