var searchData=
[
  ['assemblyinfo_2ecs',['AssemblyInfo.cs',['../_properties_2_assembly_info_8cs.html',1,'(Global Namespace)'],['../_quiz_2_properties_2_assembly_info_8cs.html',1,'(Global Namespace)']]]
];
