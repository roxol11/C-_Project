var searchData=
[
  ['koniec_5fgry',['koniec_gry',['../class_quiz_1_1koniec__gry.html#a89d24b1b80804a9c27b1bb5f8fbe5274',1,'Quiz::koniec_gry']]]
];
