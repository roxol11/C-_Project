var searchData=
[
  ['form1',['Form1',['../class_quiz_1_1_form1.html#ac1fb4002b8f982250c5e3f164e805dd0',1,'Quiz.Form1.Form1()'],['../class_quiz_1_1_form1.html#ac1fb4002b8f982250c5e3f164e805dd0',1,'Quiz.Form1.Form1()']]],
  ['funkcja_5fprzyciskow',['funkcja_przyciskow',['../class_quiz_1_1_q_u_i_z.html#a4b80197f1cab998cab42862c40f92730',1,'Quiz::QUIZ']]]
];
