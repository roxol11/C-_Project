var searchData=
[
  ['name',['name',['../class_quiz_1_1startgame.html#a6c9156b0570418b99ab2ecd4d37bc5be',1,'Quiz::startgame']]]
];
