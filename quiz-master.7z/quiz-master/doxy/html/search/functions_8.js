var searchData=
[
  ['wys_5fpytanie',['wys_pytanie',['../class_quiz_1_1_q_u_i_z.html#a1df1f252ac59e7f11960f2659d42a2f0',1,'Quiz::QUIZ']]]
];
