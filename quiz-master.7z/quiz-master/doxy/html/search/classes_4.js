var searchData=
[
  ['resources',['Resources',['../class_quiz_1_1_properties_1_1_resources.html',1,'Quiz::Properties']]]
];
