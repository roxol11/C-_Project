var searchData=
[
  ['resources',['Resources',['../class_quiz_1_1_properties_1_1_resources.html',1,'Quiz::Properties']]],
  ['resources_2edesigner_2ecs',['Resources.Designer.cs',['../_properties_2_resources_8_designer_8cs.html',1,'(Global Namespace)'],['../_quiz_2_properties_2_resources_8_designer_8cs.html',1,'(Global Namespace)']]]
];
